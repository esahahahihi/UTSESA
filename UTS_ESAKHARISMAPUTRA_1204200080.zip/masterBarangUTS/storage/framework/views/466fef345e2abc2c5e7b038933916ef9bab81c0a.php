<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,
initial-scale=1.0">
    <title>UTS ESA KHAPOED</title>
    <?php echo app('Illuminate\Foundation\Vite')('resources/sass/app.scss'); ?>
</head>

<body>
    <div class="container text-center my-5">
        <h1 class="mb-4">SELAMAT DATANG DI UTS ESA</h1>
        <img class="img-thumbnail" src="<?php echo e(Vite::asset('resources/images/logo.png')); ?>" alt="image">
        <div class="col-md-2 offset-md-5 mt-4">
            <div class="d-grid gap-2">
                <a class="btn btn-dark" href="<?php echo e(route('home')); ?>">Home</a>
            </div>
        </div>
        <h3 class="mb-4">"ทุกอย่างมีวันสิ้นสุด อะไรๆ ก็ผ่านไป ทำใจให้สบาย ทุกอย่างจะผ่านไปด้วยดี"</h3>
    </div>
    <?php echo app('Illuminate\Foundation\Vite')('resources/js/app.js'); ?>
</body>

</html>
<?php /**PATH E:\IT TELKOM\Semester 6\Pemrograman Framework\UTS\masterBarangUTS\resources\views/welcome.blade.php ENDPATH**/ ?>