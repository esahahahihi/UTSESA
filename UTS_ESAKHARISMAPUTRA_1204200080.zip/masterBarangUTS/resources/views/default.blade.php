<div class="container mt-4">
    <div class="text-center">
        <img src="{{ Vite::asset('resources/images/gambar.png') }}" class="rounded" alt="images">
    </div>
    <hr>
    <div class="d-flex align-items-center py-2 px-4 bg-light rounded-3
    border">
        <div class="bi-clipboard2-data-fill me-3 fs-1"></div>
        <h4 class="mb-0">Data Diri</h4>
    </div>
    <div class="d-flex align-items-center py-3 px-5 bg-light rounded-3
    border">
        <h4 class="mb-0">Esa Kharisma Putra</h4>
    </div>
    <div class="d-flex align-items-center py-3 px-5 bg-light rounded-3
    border">
        <h4 class="mb-0">NIM 1204200080</h4>
    </div>
    <div class="d-flex align-items-center py-3 px-5 bg-light rounded-3
    border">
        <h4 class="mb-0">Kelas IS-03-03</h4>
    </div>
    <div class="d-flex align-items-center py-3 px-5 bg-light rounded-3
    border">
        <h4 class="mb-0">PLUMPANG, TUBAN, JAWA TIMUR</h4>
    </div>
</div>
