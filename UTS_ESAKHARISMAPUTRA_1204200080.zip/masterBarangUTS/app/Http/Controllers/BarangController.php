<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Models\Barang;
use App\Models\Satuan;
use Illuminate\Support\Facades\DB;

class BarangController extends Controller
{
    public function index()
    {

        $pageTitle = 'Daftar Barang';

        // ELOQUENT
        $barangs = Barang::all();

        return view('barang.index', [
            'pageTitle' => $pageTitle,
            'barangs' => $barangs
        ]);

    }

    public function create()
    {
        $pageTitle = 'Tambah Barang';

        // ELOQUENT
        $satuans = Satuan::all();

        return view('barang.tambah', compact('pageTitle', 'satuans'));
    }

    public function store(Request $request)
    {
        $messages = [
            'required' => 'Harap Diisi dengan benar',
            'min' => 'Harap diisi lebih dari sama dengan 3 karakter',
            'max' => 'Harap diisi kurang dari sama dengan 5 karakter',
            'alpha_num' => 'Hanya bisa diidi oleh angka dan huruf saja',
            'numeric' => 'Harap diisi dengan format angka'

        ];
        $validator = Validator::make($request->all(), [
            'kodeBarang' => 'required | min:3 | max:5 | alpha_num ',
            'namaBarang' => 'required',
            'hargaBarang' => 'required | numeric',
            'deskripsiBarang' => 'required',
            'satuan_id' => 'numeric',
        ], $messages);

        if ($validator->fails()) {
            return redirect()->back()->withErrors($validator)->withInput();
        }

        //ELOQUENT
        $barang = New Barang;
        $barang->kodeBarang = $request->kodeBarang;
        $barang->namaBarang = $request->namaBarang;
        $barang->hargaBarang= $request->hargaBarang;
        $barang->deskripsiBarang = $request->deskripsiBarang;
        $barang->satuan_id = $request->satuan;
        $barang->save();

        return redirect()->route('barangs.index');
    }

    public function show(string $id)
    {
        $pageTitle = 'Detail Barang';

        // ELOQUENT
        $barang = Barang::find($id);

        return view('barang.tampil', compact('pageTitle', 'barang'));


    }

    public function edit(string $id)
    {
        $pageTitle = 'Edit Data Barang';

        // ELOQUENT
        $satuans = Satuan::all();
        $barang = Barang::find($id);


        return view('barang.edit', compact('pageTitle', 'satuans', 'barang'));

    }

    public function update(Request $request, string $id)
    {
        $messages = [
            'required' => 'Harap Diisi dengan benar',
            'min' => 'Harap diisi lebih dari sama dengan 3 karakter',
            'max' => 'Harap diisi kurang dari sama dengan 5 karakter',
            'alpha_num' => 'Hanya bisa diidi oleh angka dan huruf saja',
            'numeric' => 'Harap diisi dengan format angka'
        ];

        $validator = Validator::make($request->all(), [
            'kodeBarang' => 'required | min:3 | max:5 | alpha_num ',
            'namaBarang' => 'required',
            'hargaBarang' => 'required | numeric',
            'deskripsiBarang' => 'required',
            'satuan_id' => 'numeric',
        ], $messages);

        if ($validator->fails()) {
            return redirect()->back()->withErrors($validator)->withInput();
        }

        // ELOQUENT
        $barang = Barang::find($id);
        $barang->kodeBarang = $request->kodeBarang;
        $barang->namaBarang = $request->namaBarang;
        $barang->hargaBarang= $request->hargaBarang;
        $barang->deskripsiBarang = $request->deskripsiBarang;
        $barang->satuan_id = $request->satuan;
        $barang->save();

        return redirect()->route('barangs.index');
    }


    public function destroy(string $id)
    {
        // ELOQUENT
        Barang::find($id)->delete();

    return redirect()->route('barangs.index');

    }
}
